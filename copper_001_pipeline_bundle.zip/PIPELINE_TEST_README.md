# COPPER_001 — full pipeline test (Bang / Evidence Compiler harness)

This bundle contains the **PowerShell tracker**, **sample JSON outputs** from a successful end-to-end run, and **exact commands** to reproduce the pipeline on your machine.

## What you need first

1. **Bang repo** (this workspace): `SowSmith\Bang` — Python 3.x with project deps (`openpyxl`, etc.; use the repo’s usual venv/conda install).
2. **Validation pack extracted** so this path exists (adjust if you unpacked elsewhere):

   `...\purtera_copper_low_voltage_validation_packs\real_data_cases\`

   The public ZIP is typically named `purtera_copper_low_voltage_public_validation_packs.zip`. After extract, the case lives at:

   `...\real_data_cases\COPPER_001_SPRING_LAKE_AUDITORIUM\`

3. Edit **`run_copper_001_tracker.ps1`** if your paths differ:
   - `$Repo` — root of the Bang checkout (contains `scripts\`).
   - `$Root` — directory that **directly contains** the case folders (`COPPER_001_...`, etc.), i.e. the `real_data_cases` folder inside the extracted validation pack.

## Entire pipeline (what the tracker runs)

Run from **PowerShell**, repo root implied by the script’s `Set-Location $Repo`:

| Step | What | Command (inside tracker) |
|------|------|---------------------------|
| 1 | Paths | Verifies `$Root` and case folder exist; ensures `outputs\` exists. |
| 2 | **Compile** | `python scripts/compile_real_data_case.py --case-id COPPER_001_SPRING_LAKE_AUDITORIUM --root <Root>` |
| 3 | Check | Expects `outputs\compile_result.json` and `outputs\benchmark_summary.json`. |
| 4 | **Coverage** | `python scripts/evidence_coverage_report.py --compile-result ...\compile_result.json --out ...\coverage.json` |
| 5 | **Review queue** | `python scripts/build_review_queue.py --compile-result ...\compile_result.json --out ...\review_queue.json` |
| 6 | Summary | Inline Python: atoms, packets, families, `invalid_governance_count`. |

**One-liner to run the tracker** (after unzipping this bundle, edit `$Repo` / `$Root` in the script if needed):

```powershell
cd <path-to-Bang-repo>
powershell -NoProfile -ExecutionPolicy Bypass -File .\run_copper_001_tracker.ps1
```

If the script lives next to this README inside the bundle folder:

```powershell
cd <path-to-Bang-repo>
powershell -NoProfile -ExecutionPolicy Bypass -File .\copper_001_pipeline_bundle\run_copper_001_tracker.ps1
```

## Compile-only (no coverage / queue)

```powershell
cd <path-to-Bang-repo>
python scripts/compile_real_data_case.py --case-id COPPER_001_SPRING_LAKE_AUDITORIUM --root "<path-to-extracted-pack>\purtera_copper_low_voltage_validation_packs\real_data_cases"
```

Outputs are **always** written next to the case:

`<Root>\COPPER_001_SPRING_LAKE_AUDITORIUM\outputs\compile_result.json`  
`<Root>\COPPER_001_SPRING_LAKE_AUDITORIUM\outputs\benchmark_summary.json`

## Parser / quote tests (not the full compile pipeline)

Some Windows environments need plugin autoload disabled for pytest:

```powershell
cd <path-to-Bang-repo>
set PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
python -m pytest tests/test_quote_parser.py tests/parser_adversarial/test_quote_adversarial.py -q
```

## Sample outputs in this zip (`sample_outputs/`)

These are a **snapshot** from one pipeline run (same filenames as a live run):

- `compile_result.json` — full compile graph: atoms, packets, manifest, warnings.
- `benchmark_summary.json` — counts, packet families, `invalid_governance_count`, warnings list.
- `coverage.json` — evidence coverage report.
- `review_queue.json` — active-learning style review queue from compile result.

Use them to diff your local run or to onboard reviewers without re-running compile.

## Gold / manual validation

Per-case expected packets live in the **extracted** pack (not in this zip):

`<Root>\COPPER_001_SPRING_LAKE_AUDITORIUM\labels\gold_packets.json`

Compare packet families and anchors from `compile_result.json` to that file after copper domain pack and packetizer work land.

## Notes

- **`summarize_failures.py`** expects JSON with `failure_records`; raw `compile_result.json` usually does **not** populate that — use benchmark/adversarial reports if you wire failure records there.
- Domain pack for copper-specific behavior is **separate** from this bundle; compile uses whatever `compile_case` / `compile_project` loads (see Bang `app/domain/`).
